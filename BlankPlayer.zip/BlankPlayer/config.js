// config.js - Panto Player config
// http://freemusicarchive.org/genre/Classical/?sort=track_date_published&d=1&page=25

// Config settings

var panto={
	// title text
	title:"Izzys is the best",

	// sound files
	sounds:[
//		{title:"Splash",file:"splash.wav"},
//		{title:"Phone",file:"phone.wav",loop:true}
		],

	// song files
	songs:[
//		{title:"Classical 1",file:"classical1.mp3"},
//		{title:"Classical 2",file:"classical2.mp3"}
		]
};

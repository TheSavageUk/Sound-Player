// player.js - Panto Player

// Helper functions

function $(id) {return (typeof id=="string")?document.getElementById(id):id;}
function html(id,html) {$(id).innerHTML=html;}

// Local functions

// fullscreen
// Call to enter fullscreen mode

function fullscreen()
{
	var e=document.body,
		fn=e.requestFullScreen || e.webkitRequestFullScreen ||
		e.mozRequestFullScreen || e.msRequestFullScreen;

	if(fn) fn.call(e);
}

// load
// Call to load a bank of samples

function load(bank,colour)
{
	var h="",
		p=bank+"s",
		l=panto[p].length;

	for(var n=0;n<l;n++)
	{
		var o=panto[p][n],
			a=o.loop?" loop":"";

		h+="<audio id=\""+bank+n+"\" src=\""+bank+"s/"+o.file+"\""+a+"></audio>"+
			"<button onclick=\"onsample('"+bank+"',"+n+")\" class=\""+colour+a+"\">"+o.title+"</button>";
	}
	return h;
}

// play
// Call to play sample from a bank

function play(bank,n)
{
	var e=$(bank+n);

	e.currentTime=0;
	e.play();
}

// stop
// Call to stop all samples in a bank

function stop(bank)
{
	var p=bank+"s",
		l=panto[p].length;

	for(var n=0;n<l;n++)
	{
		var e=$(bank+n);

		e.pause();
//		e.currentTime=0;
	}
}

// Event handlers

// onload
// Called when page is loaded

function onload()
{
	html("caption",panto.title);

	html("sounds",load("sound","yellow"));
	html("songs",load("song","blue"));
}

// onfullscreen
// Called when title is pressed

function onfullscreen()
{
	fullscreen();
}

// onsample
// Called when sample button pressed

function onsample(bank,n)
{
	play(bank,n);
}

// onstop
// Called when stop button pressed

function onstop()
{
	stop("sound");
	stop("song");
}
